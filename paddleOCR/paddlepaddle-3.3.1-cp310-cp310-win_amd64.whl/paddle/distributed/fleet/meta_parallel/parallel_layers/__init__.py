# Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .mp_layers import (  # noqa: F401
    ColumnParallelLinear,
    ParallelCrossEntropy,
    RowParallelLinear,
    VocabParallelEmbedding,
)
from .pp_layers import (  # noqa: F401
    LayerDesc,
    LocalSharedLayerDesc,
    PipelineLayer,
    SharedLayerDesc,
)
from .random import (  # noqa: F401
    RNGStatesTracker,
    get_rng_state_tracker,
    model_parallel_random_seed,
)
from .spec_utils import (
    LayerSpec as LayerSpec,
    build_spec_layer as build_spec_layer,
    get_spec_layer as get_spec_layer,
    import_spec_layer as import_spec_layer,
)

__all__ = []
