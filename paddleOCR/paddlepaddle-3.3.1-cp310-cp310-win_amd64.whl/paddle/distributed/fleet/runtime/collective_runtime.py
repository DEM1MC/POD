# Copyright (c) 2020 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

from .runtime_base import RuntimeBase

__all__ = []


class CollectiveRuntime(RuntimeBase):
    def __init__(self):
        super().__init__()

    def _init_worker(self):
        logging.warning(
            "You should not call 'init_worker' method for collective mode."
        )

    def _run_worker(self):
        logging.warning(
            "You should not call 'run_worker' method for collective mode."
        )

    def _init_server(self, *args, **kwargs):
        logging.warning(
            "You should not call 'init_server' method for collective mode."
        )

    def _run_server(self):
        logging.warning(
            "You should not call 'run_server' method for collective mode."
        )

    def _stop_worker(self):
        logging.warning(
            "You should not call 'stop_worker' method for collective mode."
        )

    # save inference model should be added here
